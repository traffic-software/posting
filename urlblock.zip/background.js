
		chrome.webRequest.onBeforeRequest.addListener(
			function(d){return {cancel:true};},
			{urls:["*://pe.skokka.com/static/js/*"]},
			["blocking", 'responseHeaders']
			);
		